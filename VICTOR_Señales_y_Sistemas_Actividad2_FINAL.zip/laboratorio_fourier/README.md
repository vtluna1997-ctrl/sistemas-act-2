# Laboratorio de señales y transformada de Fourier

Este proyecto compara un pulso rectangular, una función escalón y una senoide en los dominios del tiempo y de la frecuencia. Calcula la transformada discreta mediante `np.fft.fft()`, grafica magnitud y fase, y comprueba linealidad, desplazamiento temporal y cambio de frecuencia.

## Ejecutar

Se requiere Python 3.10 o posterior. En la carpeta del proyecto:

```bash
python -m venv .venv
```

Activa el entorno virtual con `.venv\Scripts\activate` en Windows o `source .venv/bin/activate` en macOS y Linux. Instala las dependencias y ejecuta:

```bash
python -m pip install -r requirements.txt
python analisis.py
```

La carpeta `resultados/` contiene las cinco gráficas generadas y `resumen.txt`. También se incluyen en el ZIP para verlos directamente al subir el proyecto a GitHub.

## Parámetros y lectura

La frecuencia de muestreo es de 240 Hz y se observan 480 muestras durante 2 segundos. La separación entre frecuencias de la FFT es 0.5 Hz. El pulso dura 0.30 segundos; el escalón ocurre en el segundo 1; la senoide tiene 10 Hz y fase inicial π/4.

La FFT se divide entre 480. Una senoide real de amplitud unitaria presenta dos picos de magnitud 0.5 en ±10 Hz. Al duplicar su frecuencia, los picos pasan a ±20 Hz. El desplazamiento de 24 muestras es **circular**, conforme a la periodicidad implícita de la DFT: mantiene la magnitud y cambia la fase. La fase de componentes casi nulas se oculta porque allí su ángulo es inestable.

El escalón se analiza en un registro finito. Su espectro incluye el efecto de los límites del registro y no representa la transformada continua del escalón ideal infinito.

## Archivos

| Archivo | Contenido |
| --- | --- |
| `analisis.py` | Simulación, FFT, gráficas y comprobaciones comentadas. |
| `requirements.txt` | Dependencias de Python. |
| `resultados/pulso_rectangular.png` | Pulso en tiempo, magnitud y fase. |
| `resultados/escalon.png` | Escalón en tiempo, magnitud y fase. |
| `resultados/senoide_10hz.png` | Senoide de 10 Hz en los dos dominios. |
| `resultados/desplazamiento.png` | Magnitud y cambio de fase tras mover el pulso. |
| `resultados/escalamiento.png` | Comparación de 10 y 20 Hz. |
| `resultados/resumen.txt` | Parámetros y errores numéricos. |

Para publicarlo, crea un repositorio vacío en GitHub y carga el contenido de esta carpeta. Añade el enlace de tu repositorio a la diapositiva final de la presentación.
