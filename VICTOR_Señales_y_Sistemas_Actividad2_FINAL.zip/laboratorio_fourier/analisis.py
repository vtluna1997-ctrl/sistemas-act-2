"""Simulación y análisis de tres señales con la FFT de NumPy.

Ejecutar desde la carpeta del proyecto: python analisis.py
Las gráficas y el resumen se guardan en resultados/.
"""

from pathlib import Path

import matplotlib

matplotlib.use("Agg")  # Genera PNG también en equipos sin pantalla gráfica.
import matplotlib.pyplot as plt
import numpy as np


FS = 240                 # Frecuencia de muestreo, en muestras por segundo.
DURACION = 2.0           # Segundos observados.
N = int(FS * DURACION)   # 480 muestras; separación de frecuencias = 0.5 Hz.
T = np.arange(N) / FS
F = np.fft.fftshift(np.fft.fftfreq(N, d=1 / FS))
SALIDA = Path(__file__).resolve().parent / "resultados"

# Colores empleados en todas las figuras de la presentación.
VERDE = "#315C4B"
NARANJA = "#C2733D"
MORADO = "#755A8B"
FONDO = "#F6F3EB"


def espectro(senal):
    """Transformada discreta centrada y normalizada por N."""
    return np.fft.fftshift(np.fft.fft(senal)) / N


def preparar_grafica():
    plt.rcParams.update({
        "figure.facecolor": FONDO, "axes.facecolor": FONDO,
        "font.family": "DejaVu Sans", "font.size": 10,
        "axes.spines.top": False, "axes.spines.right": False,
        "axes.edgecolor": "#9B9D93", "axes.labelcolor": "#233B32",
        "xtick.color": "#233B32", "ytick.color": "#233B32",
        "text.color": "#233B32",
    })


def guardar(figura, nombre):
    figura.savefig(SALIDA / nombre, dpi=170, facecolor=FONDO, bbox_inches="tight")
    plt.close(figura)


def graficar_senal(nombre, senal):
    """Traza tiempo, magnitud y fase sobre ejes con sus unidades."""
    X = espectro(senal)
    magnitud = np.abs(X)
    fase = np.angle(X)

    # Un ángulo asociado a amplitud casi cero es inestable: se oculta.
    fase[magnitud < 0.01 * magnitud.max()] = np.nan
    banda = np.abs(F) <= 35
    fig, ejes = plt.subplots(1, 3, figsize=(13.2, 3.4), layout="constrained")

    ejes[0].plot(T, senal, color=VERDE, linewidth=2)
    ejes[0].set(xlabel="Tiempo (s)", ylabel="Amplitud", xlim=(0, DURACION),
                title="Señal muestreada")
    ejes[1].plot(F[banda], magnitud[banda], color=NARANJA, linewidth=1.8)
    ejes[1].set(xlabel="Frecuencia (Hz)", ylabel="|X[k]| / N", title="Magnitud")
    ejes[2].scatter(F[banda], fase[banda], color=MORADO, s=10)
    ejes[2].set(xlabel="Frecuencia (Hz)", ylabel="Ángulo (rad)",
                ylim=(-3.4, 3.4), title="Fase")
    for eje in ejes:
        eje.grid(alpha=0.17)
    guardar(fig, f"{nombre}.png")


def graficar_desplazamiento(original, desplazada):
    """Ilustra magnitud conservada y cambio de fase tras np.roll."""
    X, Y = espectro(original), espectro(desplazada)
    banda = np.abs(F) <= 25
    validos = banda & (np.abs(X) > 0.01 * np.max(np.abs(X)))
    fig, ejes = plt.subplots(1, 2, figsize=(9.8, 3.5), layout="constrained")
    ejes[0].plot(F[banda], np.abs(X[banda]), color=VERDE, lw=2, label="Original")
    ejes[0].plot(F[banda], np.abs(Y[banda]), color=NARANJA, lw=1.4,
                 ls="--", label="Desplazada")
    ejes[0].set(xlabel="Frecuencia (Hz)", ylabel="|X[k]| / N",
                title="Magnitud superpuesta")
    ejes[0].legend(frameon=False)
    ejes[1].scatter(F[validos], np.angle(Y[validos] / X[validos]),
                    color=MORADO, s=12)
    ejes[1].set(xlabel="Frecuencia (Hz)", ylabel="Cambio de fase (rad)",
                ylim=(-3.4, 3.4), title="Diferencia de fase")
    for eje in ejes:
        eje.grid(alpha=0.17)
    guardar(fig, "desplazamiento.png")


def graficar_escalamiento(seno_10, seno_20):
    """Compara 10 y 20 Hz en tiempo y en frecuencia."""
    positivos = (F >= 0) & (F <= 27)
    fig, ejes = plt.subplots(1, 2, figsize=(9.8, 3.5), layout="constrained")
    ejes[0].plot(T, seno_10, color=VERDE, label="10 Hz")
    ejes[0].plot(T, seno_20, color=NARANJA, alpha=0.8, label="20 Hz")
    ejes[0].set(xlim=(0, .4), xlabel="Tiempo (s)", ylabel="Amplitud",
                title="Frecuencia duplicada")
    for senal, etiqueta, color in ((seno_10, "10 Hz", VERDE),
                                    (seno_20, "20 Hz", NARANJA)):
        ejes[1].stem(F[positivos], np.abs(espectro(senal)[positivos]),
                     linefmt=color, markerfmt="o", basefmt=" ", label=etiqueta)
    ejes[1].set(xlabel="Frecuencia (Hz)", ylabel="|X[k]| / N",
                title="Picos positivos")
    for eje in ejes:
        eje.grid(alpha=0.17)
        eje.legend(frameon=False)
    guardar(fig, "escalamiento.png")


def main():
    SALIDA.mkdir(exist_ok=True)
    preparar_grafica()

    # El pulso se activa de 0.35 a 0.65 s; el escalón comienza en 1 s.
    pulso = ((T >= .35) & (T < .65)).astype(float)
    escalon = (T >= 1.0).astype(float)
    # La fase inicial pi/4 hace visible su efecto en el espectro de la senoide.
    seno_10 = np.sin(2 * np.pi * 10 * T + np.pi / 4)
    seno_20 = np.sin(2 * np.pi * 20 * T + np.pi / 4)

    for nombre, senal in (("pulso_rectangular", pulso),
                          ("escalon", escalon), ("senoide_10hz", seno_10)):
        graficar_senal(nombre, senal)

    # Linealidad: FFT(a·p+b·s) y a·FFT(p)+b·FFT(s) deben coincidir.
    a, b = .5, 1.25
    error_lineal = np.max(np.abs(espectro(a * pulso + b * seno_10)
                                   - a * espectro(pulso) - b * espectro(seno_10)))

    # La DFT considera periódico el registro; por eso se usa un giro circular.
    m = 24  # 24 muestras a 240 Hz = 0.10 segundos.
    desplazada = np.roll(pulso, m)
    X, Y = espectro(pulso), espectro(desplazada)
    indices = np.fft.fftshift(np.fft.fftfreq(N))
    factor = np.exp(-2j * np.pi * indices * m)
    error_desplazamiento = np.max(np.abs(Y - X * factor))
    error_magnitud = np.max(np.abs(np.abs(Y) - np.abs(X)))
    graficar_desplazamiento(pulso, desplazada)
    graficar_escalamiento(seno_10, seno_20)

    # Validaciones de contenido: detectan errores de definición o unidades.
    assert error_lineal < 1e-12
    assert error_desplazamiento < 1e-12
    assert error_magnitud < 1e-12
    assert np.isclose(F[F >= 0][np.argmax(np.abs(espectro(seno_10)[F >= 0]))], 10)
    assert np.isclose(F[F >= 0][np.argmax(np.abs(espectro(seno_20)[F >= 0]))], 20)

    resumen = (
        f"fs={FS} Hz, N={N}, duración={DURACION:g} s, Δf={FS/N:.1f} Hz\n"
        "Pulso: intervalo [0.35, 0.65) s; escalón: t >= 1.0 s.\n"
        "Senoide: 10 Hz, amplitud 1 y fase inicial π/4.\n"
        f"Linealidad, error máximo: {error_lineal:.3e}\n"
        f"Desplazamiento circular: {m} muestras = {m/FS:.2f} s\n"
        f"Desplazamiento, error máximo: {error_desplazamiento:.3e}\n"
        f"Magnitud, diferencia máxima: {error_magnitud:.3e}\n"
        "Escalamiento: picos de ±10 Hz a ±20 Hz.\n"
    )
    (SALIDA / "resumen.txt").write_text(resumen, encoding="utf-8")
    print(resumen)


if __name__ == "__main__":
    main()
